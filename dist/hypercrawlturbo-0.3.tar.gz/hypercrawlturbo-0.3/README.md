# HypercrawlTurbo

HypercrawlTurbo is a turbocharged web scraper for extracting URLs from a webpage.

## Installation

You can install HypercrawlTurbo via pip:

```bash
pip install hypercrawlturbo
